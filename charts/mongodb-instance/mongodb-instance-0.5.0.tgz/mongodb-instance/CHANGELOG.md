# Changelog

## [0.5.0](https://github.com/plopoyop/mongodb-for-kubernetes-community/tree/0.5.0) (2026-08-03)

[Full Changelog](https://github.com/plopoyop/mongodb-for-kubernetes-community/compare/0.4.1...0.5.0)

## 🚀 New Features

- Multiple enhancements [\#52](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/52) ([plopoyop](https://github.com/plopoyop))
- Add initContainer additionnal config [\#51](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/51) ([plopoyop](https://github.com/plopoyop))

## ⚙️ Dependencies

- feat\(ci\): update renovatebot/github-action action \(v46.1.20 → v46.2.0\) [\#50](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/50) ([plopoyop](https://github.com/plopoyop))
- fix\(ci\): update renovatebot/github-action action \(v46.1.19 → v46.1.20\) [\#48](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/48) ([plopoyop](https://github.com/plopoyop))
- fix\(ci\): update renovatebot/github-action action \(v46.1.18 → v46.1.19\) [\#46](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/46) ([plopoyop](https://github.com/plopoyop))
- fix\(ci\): update renovatebot/github-action action \(v46.1.17 → v46.1.18\) [\#45](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/45) ([plopoyop](https://github.com/plopoyop))

**Merged pull requests:**

- feat\(deps\): update git \(2.54.0 → 2.55.0\) [\#49](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/49) ([plopoyop](https://github.com/plopoyop))
- feat\(deps\): update prek \(0.3.11 → 0.4.4\) [\#47](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/47) ([plopoyop](https://github.com/plopoyop))

## [0.4.1](https://github.com/plopoyop/mongodb-for-kubernetes-community/tree/0.4.1) (2026-07-05)

[Full Changelog](https://github.com/plopoyop/mongodb-for-kubernetes-community/compare/0.4.0...0.4.1)

## ⚙️ Dependencies

- fix\(ci\): update renovatebot/github-action action \(v46.1.16 → v46.1.17\) [\#44](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/44) ([plopoyop](https://github.com/plopoyop))

## [0.4.0](https://github.com/plopoyop/mongodb-for-kubernetes-community/tree/0.4.0) (2026-07-01)

[Full Changelog](https://github.com/plopoyop/mongodb-for-kubernetes-community/compare/0.3.1...0.4.0)

## 🚀 New Features

- Create certificate and enable TLS encryption [\#42](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/42) ([plopoyop](https://github.com/plopoyop))
- Create additionnal users [\#41](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/41) ([plopoyop](https://github.com/plopoyop))

## [0.3.1](https://github.com/plopoyop/mongodb-for-kubernetes-community/tree/0.3.1) (2026-07-01)

[Full Changelog](https://github.com/plopoyop/mongodb-for-kubernetes-community/compare/0.3.0...0.3.1)

## 🐛 Bug Fixes

- Change password on default static install [\#43](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/43) ([plopoyop](https://github.com/plopoyop))

## [0.3.0](https://github.com/plopoyop/mongodb-for-kubernetes-community/tree/0.3.0) (2026-07-01)

[Full Changelog](https://github.com/plopoyop/mongodb-for-kubernetes-community/compare/0.2.6...0.3.0)

## 🚀 New Features

- Prevent install when admin password is not changed [\#40](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/40) ([plopoyop](https://github.com/plopoyop))

## ⚙️ Dependencies

- feat\(ci\)!: Update actions/checkout action \(v6.0.3 → v7.0.0\) [\#38](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/38) ([plopoyop](https://github.com/plopoyop))

## [0.2.6](https://github.com/plopoyop/mongodb-for-kubernetes-community/tree/0.2.6) (2026-06-28)

[Full Changelog](https://github.com/plopoyop/mongodb-for-kubernetes-community/compare/0.2.5...0.2.6)

## ⚙️ Dependencies

- fix\(ci\): update renovatebot/github-action action \(v46.1.15 → v46.1.16\) [\#37](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/37) ([plopoyop](https://github.com/plopoyop))

## [0.2.5](https://github.com/plopoyop/mongodb-for-kubernetes-community/tree/0.2.5) (2026-06-19)

[Full Changelog](https://github.com/plopoyop/mongodb-for-kubernetes-community/compare/0.2.4...0.2.5)

## 🐛 Bug Fixes

- Fix Cronjob release name [\#36](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/36) ([plopoyop](https://github.com/plopoyop))

## ⚙️ Dependencies

- fix\(ci\): update renovatebot/github-action action \(v46.1.14 → v46.1.15\) [\#35](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/35) ([plopoyop](https://github.com/plopoyop))
- feat\(ci\)!: Update helm \(v3.21.0 → v4.2.0\) [\#34](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/34) ([plopoyop](https://github.com/plopoyop))
- feat\(ci\): update helm \(v3.19.1 → v3.21.0\) [\#33](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/33) ([plopoyop](https://github.com/plopoyop))
- fix\(ci\): update renovatebot/github-action action \(v46.1.13 → v46.1.14\) [\#30](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/30) ([plopoyop](https://github.com/plopoyop))
- fix\(ci\): update renovatebot/github-action action \(v46.1.12 → v46.1.13\) [\#28](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/28) ([plopoyop](https://github.com/plopoyop))
- fix\(ci\): update renovatebot/github-action action \(v46.1.10 → v46.1.12\) [\#26](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/26) ([plopoyop](https://github.com/plopoyop))
- fix\(ci\): update renovatebot/github-action action \(v46.1.9 → v46.1.10\) [\#24](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/24) ([plopoyop](https://github.com/plopoyop))

**Merged pull requests:**

- feat\(deps\): update git \(2.53.0 → 2.54.0\) [\#32](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/32) ([plopoyop](https://github.com/plopoyop))
- feat\(deps\): update kubernetes-helm \(3.19.1 → 3.20.2\) [\#31](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/31) ([plopoyop](https://github.com/plopoyop))
- fix\(deps\): update prek \(0.3.10 → 0.3.11\) [\#29](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/29) ([plopoyop](https://github.com/plopoyop))
- fix\(deps\): update prek \(0.3.9 → 0.3.10\) [\#27](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/27) ([plopoyop](https://github.com/plopoyop))
- fix\(deps\): update prek \(0.3.8 → 0.3.9\) [\#25](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/25) ([plopoyop](https://github.com/plopoyop))

## [0.2.4](https://github.com/plopoyop/mongodb-for-kubernetes-community/tree/0.2.4) (2026-04-22)

[Full Changelog](https://github.com/plopoyop/mongodb-for-kubernetes-community/compare/0.2.3...0.2.4)

## 🐛 Bug Fixes

- Remove deprecaded 'Persistant' property [\#23](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/23) ([plopoyop](https://github.com/plopoyop))

## ⚙️ Dependencies

- feat\(ci\)!: Update azure/setup-helm action \(v4 → v5\) [\#22](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/22) ([plopoyop](https://github.com/plopoyop))
- fix\(ci\): update renovatebot/github-action action \(v46.1.8 → v46.1.9\) [\#21](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/21) ([plopoyop](https://github.com/plopoyop))
- fix\(ci\): update renovatebot/github-action action \(v46.1.7 → v46.1.8\) [\#19](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/19) ([plopoyop](https://github.com/plopoyop))
- feat\(ci\): update jetify-com/devbox-install-action action \(v0.14.0 → v0.15.0\) [\#18](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/18) ([plopoyop](https://github.com/plopoyop))
- fix\(ci\): update renovatebot/github-action action \(v46.1.6 → v46.1.7\) [\#17](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/17) ([plopoyop](https://github.com/plopoyop))
- fix\(ci\): update renovatebot/github-action action \(v46.1.5 → v46.1.6\) [\#15](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/15) ([plopoyop](https://github.com/plopoyop))
- fix\(ci\): update renovatebot/github-action action \(v46.1.0 → v46.1.5\) [\#13](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/13) ([plopoyop](https://github.com/plopoyop))
- feat\(deps\)!: Update pre-commit hook pre-commit/pre-commit-hooks \(v5.0.0 → v6.0.0\) [\#10](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/10) ([plopoyop](https://github.com/plopoyop))
- feat\(ci\)!: Update renovatebot/github-action action \(v44.2.6 → v46.1.0\) [\#9](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/9) ([plopoyop](https://github.com/plopoyop))

**Merged pull requests:**

- fix\(deps\): update prek \(0.3.6 → 0.3.8\) [\#20](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/20) ([plopoyop](https://github.com/plopoyop))
- fix\(deps\): update prek \(0.3.5 → 0.3.6\) [\#16](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/16) ([plopoyop](https://github.com/plopoyop))
- fix\(deps\): update prek \(0.3.4 → 0.3.5\) [\#14](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/14) ([plopoyop](https://github.com/plopoyop))
- fix\(deps\): update prek \(0.3.0 → 0.3.4\) [\#12](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/12) ([plopoyop](https://github.com/plopoyop))
- feat\(deps\): update git \(2.52.0 → 2.53.0\) [\#11](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/11) ([plopoyop](https://github.com/plopoyop))
- feat\(deps\): update prek \(0.2.30 → 0.3.0\) [\#8](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/8) ([plopoyop](https://github.com/plopoyop))

## [0.2.3](https://github.com/plopoyop/mongodb-for-kubernetes-community/tree/0.2.3) (2026-02-10)

[Full Changelog](https://github.com/plopoyop/mongodb-for-kubernetes-community/compare/0.2.2...0.2.3)

## 🐛 Bug Fixes

- fix mongodb kubernetes role name [\#7](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/7) ([plopoyop](https://github.com/plopoyop))

## [0.2.2](https://github.com/plopoyop/mongodb-for-kubernetes-community/tree/0.2.2) (2026-02-09)

[Full Changelog](https://github.com/plopoyop/mongodb-for-kubernetes-community/compare/0.2.1...0.2.2)

## 🐛 Bug Fixes

- Fix Workflows [\#6](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/6) ([plopoyop](https://github.com/plopoyop))

## [0.2.1](https://github.com/plopoyop/mongodb-for-kubernetes-community/tree/0.2.1) (2026-02-09)

[Full Changelog](https://github.com/plopoyop/mongodb-for-kubernetes-community/compare/0.2.0...0.2.1)

## ⚙️ Dependencies

- fix\(ci\): update renovatebot/github-action action \(v44.2.5 → v44.2.6\) [\#4](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/4) ([plopoyop](https://github.com/plopoyop))

**Merged pull requests:**

- feat\(deps\): update go-task \(3.45.5 → 3.48.0\) [\#5](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/5) ([plopoyop](https://github.com/plopoyop))

## [0.2.0](https://github.com/plopoyop/mongodb-for-kubernetes-community/tree/0.2.0) (2026-02-09)

[Full Changelog](https://github.com/plopoyop/mongodb-for-kubernetes-community/compare/0.1.1...0.2.0)

## 🚀 New Features

- Multiple changes [\#3](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/3) ([plopoyop](https://github.com/plopoyop))

## [0.1.1](https://github.com/plopoyop/mongodb-for-kubernetes-community/tree/0.1.1) (2026-02-08)

[Full Changelog](https://github.com/plopoyop/mongodb-for-kubernetes-community/compare/0.1.0...0.1.1)

## [0.1.0](https://github.com/plopoyop/mongodb-for-kubernetes-community/tree/0.1.0) (2026-02-08)

[Full Changelog](https://github.com/plopoyop/mongodb-for-kubernetes-community/compare/ec5f60e0100f04958977c6c20b55669d464a37bd...0.1.0)

## 🚀 New Features

- Initial Chart version [\#2](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/2) ([plopoyop](https://github.com/plopoyop))
- Add repository tooling [\#1](https://github.com/plopoyop/mongodb-for-kubernetes-community/pull/1) ([plopoyop](https://github.com/plopoyop))



\* *This Changelog was automatically generated by [github_changelog_generator](https://github.com/github-changelog-generator/github-changelog-generator)*
